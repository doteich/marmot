(function(){try{var el=document.createElement('style');el.setAttribute('data-extension','tank-level');el.textContent=".tank-widget[data-v-bb93c24d]{box-sizing:border-box;-webkit-user-select:none;user-select:none;flex-direction:column;justify-content:space-between;align-items:center;width:100%;max-width:100%;height:100%;max-height:100%;padding:12px;display:flex;overflow:hidden}.tank-graphic-wrapper[data-v-bb93c24d]{flex:1;justify-content:center;align-items:center;width:100%;min-height:0;display:flex;overflow:hidden}.tank-svg[data-v-bb93c24d]{width:100%;max-width:100%;height:100%;max-height:100%;display:block}.tank-footer[data-v-bb93c24d]{flex-direction:column;flex-shrink:0;gap:6px;width:100%;margin-top:6px;display:flex}.tank-readout[data-v-bb93c24d]{justify-content:space-between;align-items:center;width:100%;font-size:12px;font-weight:600;line-height:1;display:flex}.value-text[data-v-bb93c24d]{opacity:.85}.percent-text[data-v-bb93c24d]{color:var(--app-accent,#38bdf8);font-weight:700}.tank-bar-track[data-v-bb93c24d]{background:#ffffff1f;border-radius:3px;width:100%;height:6px;overflow:hidden}.tank-bar-fill[data-v-bb93c24d]{border-radius:3px;height:100%;transition:width .35s}\n/*$vite$:1*/";document.head.appendChild(el);}catch(e){console.error('Failed to inject extension CSS',e);}})();
import { Fragment as e, computed as t, createCommentVNode as n, createElementBlock as r, createElementVNode as i, defineComponent as a, normalizeClass as o, normalizeStyle as s, openBlock as c, renderList as l, toDisplayString as u } from "vue";
//#region src/TankLevel.vue?vue&type=script&setup=true&lang.ts
var d = { class: "tank-graphic-wrapper" }, f = ["viewBox"], p = ["y", "height"], m = { class: "tank-legs" }, h = ["d", "transform"], g = ["d", "transform"], _ = ["clip-path"], v = [
	"d",
	"transform",
	"fill"
], y = ["d", "transform"], b = ["d"], x = { class: "tank-footer" }, S = { class: "tank-readout" }, C = { class: "value-text" }, w = { class: "percent-text" }, T = { class: "tank-bar-track" }, E = /*#__PURE__*/ ((e, t) => {
	let n = e.__vccOpts || e;
	for (let [e, r] of t) n[e] = r;
	return n;
})(/* @__PURE__ */ a({
	__name: "TankLevel",
	props: {
		shape: { default: "tank_barrel" },
		fillColor: { default: "#0284c7" },
		backgroundColor: { default: "" },
		capacity: { default: 1e3 },
		dataPoint: { default: "" },
		value: { default: 650 },
		telemetryValues: { default: () => ({}) }
	},
	setup(a) {
		let E = a, D = {
			tank_barrel: {
				viewBox: "0 0 82 161",
				topY: 0,
				bottomY: 150,
				legs: [{ d: "M 0 160 L 30 128 L 50 128 L 20 160 Z" }, {
					d: "M 30 160 L 60 128 L 80 128 L 50 160 Z",
					transform: "translate(0,144)scale(1,-1)translate(0,-144)"
				}],
				body: { d: "M 0 15 C 0 6.72 17.91 0 40 0 C 50.61 0 60.78 1.58 68.28 4.39 C 75.79 7.21 80 11.02 80 15 L 80 135 C 80 143.28 62.09 150 40 150 C 17.91 150 0 143.28 0 135 Z" },
				rim: "M 80 15 C 80 23.28 62.09 30 40 30 C 17.91 30 0 23.28 0 15"
			},
			tank_pin: {
				viewBox: "0 0 82 123",
				topY: 0,
				bottomY: 120,
				legs: [{
					d: "M 30 122 L 60 90 L 80 90 L 50 122 Z",
					transform: "translate(0,106)scale(1,-1)translate(0,-106)"
				}, { d: "M 0 122 L 30 90 L 50 90 L 20 122 Z" }],
				body: { d: "M 0 0 L 80 0 L 80 75 L 40 120 L 0 75 Z" },
				rim: void 0
			},
			tank_rounded: {
				viewBox: "0 0 82 121",
				topY: 0,
				bottomY: 110,
				legs: [{ d: "M 0 120 L 30 88 L 50 88 L 20 120 Z" }, {
					d: "M 30 120 L 60 88 L 80 88 L 50 120 Z",
					transform: "translate(0,104)scale(1,-1)translate(0,-104)"
				}],
				body: { d: "M 0 0 L 80 0 L 80 70 Q 80 110 40 110 Q 0 110 0 70 Z" },
				rim: void 0
			}
		}, O = "tank-clip-" + Math.random().toString(36).substring(2, 9), k = t(() => {
			let e = E.shape || "tank_barrel";
			return D[e] || D.tank_barrel;
		}), A = t(() => {
			let e = Number(E.capacity);
			return !isNaN(e) && e > 0 ? e : 1e3;
		}), j = t(() => {
			if (E.dataPoint && E.telemetryValues && E.telemetryValues[E.dataPoint] !== void 0) {
				let e = E.telemetryValues[E.dataPoint], t = typeof e == "number" ? e : parseFloat(String(e));
				return isNaN(t) ? 0 : Math.round(t);
			}
			let e = typeof E.value == "number" ? E.value : parseFloat(String(E.value));
			return isNaN(e) ? 0 : Math.round(e);
		}), M = t(() => {
			let e = j.value / A.value * 100;
			return isNaN(e) || !isFinite(e) ? 0 : Math.min(100, Math.max(0, Math.round(e)));
		}), N = t(() => {
			if (M.value <= 0) return k.value.bottomY + 10;
			let e = k.value.bottomY - k.value.topY;
			return k.value.bottomY - M.value / 100 * e;
		}), P = t(() => {
			if (M.value <= 0) return 0;
			let e = k.value.bottomY - k.value.topY;
			return M.value / 100 * e + 2;
		});
		return (t, D) => (c(), r("div", {
			class: o(["widget-card tank-widget", E.backgroundColor == "" ? "widget-glass" : ""]),
			style: s({ background: E.backgroundColor })
		}, [i("div", d, [(c(), r("svg", {
			class: "tank-svg",
			viewBox: k.value.viewBox,
			preserveAspectRatio: "xMidYMid meet"
		}, [
			i("defs", null, [i("clipPath", { id: O }, [i("rect", {
				x: "-5",
				y: N.value,
				width: "92",
				height: P.value
			}, null, 8, p)])]),
			i("g", m, [(c(!0), r(e, null, l(k.value.legs, (e, t) => (c(), r("path", {
				key: "leg-" + t,
				d: e.d,
				transform: e.transform,
				fill: "#475569"
			}, null, 8, h))), 128))]),
			i("path", {
				d: k.value.body.d,
				transform: k.value.body.transform,
				fill: "#334155",
				opacity: "0.5"
			}, null, 8, g),
			i("g", { "clip-path": `url(#${O})` }, [i("path", {
				d: k.value.body.d,
				transform: k.value.body.transform,
				fill: a.fillColor,
				opacity: "0.9"
			}, null, 8, v)], 8, _),
			i("path", {
				d: k.value.body.d,
				transform: k.value.body.transform,
				fill: "none",
				stroke: "#64748b",
				"stroke-width": "1.5"
			}, null, 8, y),
			k.value.rim ? (c(), r("path", {
				key: 0,
				d: k.value.rim,
				fill: "none",
				stroke: "#64748b",
				"stroke-width": "1.5"
			}, null, 8, b)) : n("", !0)
		], 8, f))]), i("div", x, [i("div", S, [i("span", C, u(j.value) + " / " + u(A.value), 1), i("span", w, u(M.value) + "%", 1)]), i("div", T, [i("div", {
			class: "tank-bar-fill",
			style: s({
				width: `${M.value}%`,
				backgroundColor: a.fillColor
			})
		}, null, 4)])])], 6));
	}
}), [["__scopeId", "data-v-bb93c24d"]]), D = { class: "tank-level-config marmot-config-stack" }, O = { class: "section-card" }, k = { class: "form-row" }, A = ["value"], j = { class: "form-row" }, M = { class: "color-presets" }, N = ["title", "onClick"], P = ["value"], F = { class: "form-row" }, I = { class: "color-row" }, L = ["value"], R = ["value"], z = { class: "section-card" }, B = { class: "form-row" }, V = ["value"], H = ["label"], U = ["value"], W = ["value"], G = ["value"], K = ["value"], q = { class: "form-row" }, J = ["value"], Y = {
	widgetComponent: E,
	configComponent: /* @__PURE__ */ a({
		__name: "TankLevelConfig",
		props: {
			component: {},
			dataPoints: {},
			groupedDataPoints: {}
		},
		emits: ["update"],
		setup(t, { emit: a }) {
			let d = t, f = a, p = [
				{
					label: "Sky Blue",
					color: "#0284c7"
				},
				{
					label: "Emerald",
					color: "#10b981"
				},
				{
					label: "Amber",
					color: "#f59e0b"
				},
				{
					label: "Purple",
					color: "#8b5cf6"
				},
				{
					label: "Rose",
					color: "#f43f5e"
				}
			];
			function m(e, t) {
				f("update", { [e]: t });
			}
			function h(e) {
				if (d.groupedDataPoints) {
					for (let t of d.groupedDataPoints) if (t.items?.some((t) => t.dataPointId === e)) return !0;
				}
				return !!d.dataPoints?.some((t) => t.dataPointId === e);
			}
			return (a, d) => (c(), r("div", D, [i("div", O, [
				d[11] ||= i("div", { class: "section-title" }, "Appearance", -1),
				i("div", k, [d[8] ||= i("label", null, "Tank Shape", -1), i("select", {
					value: t.component.props.shape || "tank_barrel",
					class: "inspector-select",
					onChange: d[0] ||= (e) => m("shape", e.target.value)
				}, [...d[7] ||= [
					i("option", { value: "tank_barrel" }, "Barrel Tank", -1),
					i("option", { value: "tank_pin" }, "Pin Bottom Tank", -1),
					i("option", { value: "tank_rounded" }, "Round Bottom Tank", -1)
				]], 40, A)]),
				i("div", j, [d[9] ||= i("label", null, "Fill Color", -1), i("div", M, [(c(), r(e, null, l(p, (e) => i("button", {
					key: e.color,
					type: "button",
					class: o(["color-btn", { active: (t.component.props.fillColor || "#0284c7") === e.color }]),
					style: s({ backgroundColor: e.color }),
					title: e.label,
					onClick: (t) => m("fillColor", e.color)
				}, null, 14, N)), 64)), i("input", {
					value: t.component.props.fillColor || "#0284c7",
					type: "text",
					class: "inspector-input hex-input",
					placeholder: "#0284c7",
					onInput: d[1] ||= (e) => m("fillColor", e.target.value)
				}, null, 40, P)])]),
				i("div", F, [d[10] ||= i("label", null, "Custom Background Color", -1), i("div", I, [i("input", {
					value: t.component.props.backgroundColor,
					type: "color",
					class: "color-picker",
					onInput: d[2] ||= (e) => m("backgroundColor", e.target.value)
				}, null, 40, L), i("input", {
					value: t.component.props.backgroundColor,
					type: "text",
					class: "inspector-input",
					placeholder: "#1e293b or rgba(...)",
					onInput: d[3] ||= (e) => m("backgroundColor", e.target.value)
				}, null, 40, R)])])
			]), i("div", z, [
				d[15] ||= i("div", { class: "section-title" }, "Behavior", -1),
				i("div", B, [d[13] ||= i("label", null, "Data Point (Bucketed Metrics / Telemetry)", -1), t.groupedDataPoints && t.groupedDataPoints.length > 0 || t.dataPoints && t.dataPoints.length > 0 ? (c(), r("select", {
					key: 0,
					value: t.component.props.dataPoint || "",
					class: "inspector-select",
					onChange: d[4] ||= (e) => m("dataPoint", e.target.value)
				}, [
					d[12] ||= i("option", { value: "" }, "-- Manual / Test Mode --", -1),
					t.groupedDataPoints && t.groupedDataPoints.length > 0 ? (c(!0), r(e, { key: 0 }, l(t.groupedDataPoints, (t) => (c(), r("optgroup", {
						key: t.machineId,
						label: t.machineId ? `Machine: ${t.machineId}` : "General / Other"
					}, [(c(!0), r(e, null, l(t.items, (e) => (c(), r("option", {
						key: e.dataPointId,
						value: e.dataPointId
					}, u(e.dataPointName || e.dataPointId) + " (" + u(e.dataType) + ")" + u(e.unit ? " [" + e.unit + "]" : ""), 9, U))), 128))], 8, H))), 128)) : t.dataPoints ? (c(!0), r(e, { key: 1 }, l(t.dataPoints, (e) => (c(), r("option", {
						key: e.dataPointId,
						value: e.dataPointId
					}, u(e.dataPointName || e.dataPointId) + u(e.unit ? " [" + e.unit + "]" : ""), 9, W))), 128)) : n("", !0),
					t.component.props.dataPoint && !h(t.component.props.dataPoint) ? (c(), r("option", {
						key: 2,
						value: t.component.props.dataPoint
					}, u(t.component.props.dataPoint), 9, G)) : n("", !0)
				], 40, V)) : (c(), r("input", {
					key: 1,
					value: t.component.props.dataPoint || "",
					placeholder: "e.g. Tank1.Level",
					class: "inspector-input",
					onInput: d[5] ||= (e) => m("dataPoint", e.target.value)
				}, null, 40, K))]),
				i("div", q, [d[14] ||= i("label", null, "Max Capacity", -1), i("input", {
					value: t.component.props.capacity ?? 1e3,
					type: "number",
					placeholder: "1000",
					class: "inspector-input",
					onInput: d[6] ||= (e) => m("capacity", e.target.value ? Number(e.target.value) : 1e3)
				}, null, 40, J)])
			])]));
		}
	})
};
//#endregion
export { Y as default };
